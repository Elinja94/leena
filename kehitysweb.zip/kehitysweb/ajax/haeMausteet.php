<?php
$link = mysqli_connect("magnesium", "16bsonjas", "salasana", "db16bsonjas");
$output = null;
if (mysqli_connect_errno()) {
  echo "Connect failed: %s\n" . mysqli_connect_error();
  exit();
}
else if ($result = mysqli_query($link, "SELECT * FROM tuotteet WHERE Ryhma='Mausteet'")) {
  while($row = $result->fetch_array(MYSQLI_ASSOC)) {
    $output[] = $row;
  }
  if ($output != null) {
    print(json_encode($output));
   }
   else {
     print(json_encode(null));
   }
   
   mysqli_free_result($result);
}
mysqli_close($link);
?>